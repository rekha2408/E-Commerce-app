

# For color setup

# Follow the steps mentioned below:-

i.go to project name 

ii.select lib under the project

iii.click on configuration package inside lib package.

iv.For **Primary Color and Accent Color:** 

- go to MobikulTheme.dart file inside configuration package and change the color

